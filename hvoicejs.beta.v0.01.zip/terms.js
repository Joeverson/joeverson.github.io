var terms = [
    {
        term: 'oi',
        take: function(){ alert('Oi, Seja Bem vindo ao HVoice.JS!!'); },
        desc: 'Boas Vindas do HVoice.JS'
    }
]